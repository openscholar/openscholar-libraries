/**
 * @module math
 */

export { default as Math } from './math';
export { default as AutoformatMath } from './autoformatmath';
